<div class="notification">
  <div class="notification__title">
    <p>Notifications</p>
    <a id="markAllAsRead" href="#">Mark all as read</a>
  </div>

  <div class="notification__card">
    <?php
    include '../controller/getNotification.php';
    ?>
  </div>
</div>